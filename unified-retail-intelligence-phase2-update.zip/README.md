# Unified Retail Intelligence Platform

An end-to-end cloud data and AI platform built on Databricks, PySpark, and
Delta Lake — implementing Bronze/Silver/Gold pipelines, automated data-quality
gating, MLflow-based model lifecycle management, CI/CD evaluation gates, and
a GenAI RAG/text-to-SQL assistant for natural-language analytics.

*Independent portfolio project — not built for or on behalf of any employer.*

## Architecture

```
Raw Data (synthetic retail transactions)
   |
   v
Bronze  (raw ingest, schema enforcement, lineage metadata)
   |
   v
Data Quality Gate  <-- blocks the pipeline if quality regresses
   |
   v
Silver  (cleaning, dedup, business rules, quarantine table)
   |
   v
Gold    (category sales for BI, customer features for ML)
   |
   +--> ML: churn model + MLflow tracking          [Phase 2 -- in progress]
   |
   +--> GenAI: text-to-SQL / RAG assistant           [Phase 3 -- in progress]
   |
   +--> CI/CD: GitHub Actions test + DQ gate         [done -- see .github/workflows/ci.yml]
```

## Status

- [x] **Phase 1 — Data Engineering Foundation.** Bronze -> Silver -> Gold on
      PySpark, Delta-ready (Parquet fallback locally), automated data quality
      scoring, quarantine table for failed rows, full pytest suite, CI/CD
      wired to run tests + the DQ gate on every push.
- [x] **Phase 2 — ML Model + MLflow.** Churn model (Random Forest) trained on
      `gold_customer_features`, tracked in MLflow (params/metrics/artifacts),
      registered to the MLflow Model Registry with a promotion gate (a new
      model is only promoted to Production if it beats the current
      Production ROC-AUC), plus a CI evaluation gate and inference/explanation
      script. See `docs/data_leakage_note.md` for a real bug caught and fixed
      during this phase.
- [ ] **Phase 3 — GenAI Layer.** Text-to-SQL over Gold tables + wrapping
      `ml/inference/score_customers.py --explain` in a natural-language agent.
- [ ] **Phase 4 — Full MLOps polish.** Streamlit UI, monitoring dashboard,
      Docker + deployment, incident simulation for the model layer.

## Quickstart

```bash
pip install -r requirements.txt

# 1. Generate synthetic raw data (5% realistic dirtiness injected on purpose)
python ingestion/generate_synthetic_data.py --rows 5000 --customers 800 --out data/raw/transactions.csv

# 2. Run the full pipeline: Bronze -> DQ gate -> Silver -> Gold -> train model -> model gate
python pipelines/run_pipeline.py --format parquet --dq-threshold 0.90 --model-min-auc 0.75

# 3. Run the test suite (data pipeline + model tests)
pytest tests/ -v

# 4. See the data-quality incident story in action
python data_quality/simulate_incident.py \
  --input data/lake/bronze/transactions \
  --output data/lake/bronze/_incident/transactions \
  --bad-fraction 0.30

# 5. Score customers with the Production model, or explain one customer's risk
python ml/inference/score_customers.py --input data/lake/gold/customer_features --top-n 10
python ml/inference/score_customers.py --input data/lake/gold/customer_features --explain CUST000279

# 6. Inspect experiments in the MLflow UI
mlflow ui --backend-store-uri sqlite:///mlruns.db
```

## What each layer proves

| Layer | What it demonstrates |
|---|---|
| **Bronze** | Schema-enforced ingestion, lineage metadata, incremental-load pattern |
| **Data Quality Gate** | A single interpretable score, per-rule breakdown, hard threshold that blocks bad data from propagating -- see `docs/incident_postmortem.md` for a real before/after run |
| **Silver** | Real cleaning logic (not just `.dropna()`) -- multi-rule tagging, a quarantine table instead of silent data loss, full unit test coverage |
| **Gold** | Business-ready aggregates for both BI (`category_sales`) and ML (`customer_features`), with a documented, reproducible churn label |
| **ML Training + MLflow** | Full experiment tracking, model registry, and a promotion gate that only ships a model if it's actually better -- see `docs/data_leakage_note.md` for a real bug caught in development |
| **Model Evaluation Gate** | CI-blocking check on Production model quality, same pattern as the data quality gate |
| **Inference + Explanation** | Batch scoring plus a per-customer "why is this customer high-risk" explanation -- the foundation Phase 3's GenAI agent will wrap in natural language |
| **CI/CD** | Every push runs the real pipeline (data + model) against fresh synthetic data and fails the build if either gate fails |

## Why Databricks-native, tested locally

The transform code is plain PySpark with no local-only dependencies -- see
`docs/DATABRICKS.md` for exactly what changes (Delta vs Parquet, Workflow
orchestration, Unity Catalog) when this is deployed to a real Databricks
workspace instead of run locally.

## Repo structure

```
unified-retail-intelligence/
├── ingestion/              # synthetic data generator (stand-in for a real source connector)
├── transformations/
│   ├── bronze/
│   ├── silver/
│   └── gold/
├── data_quality/           # DQ scoring + the incident simulation
├── feature_engineering/    # Phase 2
├── ml/                     # Phase 2: training / evaluation / inference
├── genai/                  # Phase 3: rag / text_to_sql / agents
├── pipelines/               # orchestrator
├── tests/
├── infrastructure/          # Phase 4
├── .github/workflows/       # CI/CD
├── docker/                  # Phase 4
├── monitoring/               # Phase 4
└── docs/
```

## Resume bullets this project supports

> Built an end-to-end cloud data and AI platform using Databricks, PySpark,
> and Delta Lake, implementing Bronze/Silver/Gold pipelines, automated
> data-quality validation with a hard deployment gate, and CI/CD testing
> via GitHub Actions.

> Trained and productionized a customer churn model with MLflow experiment
> tracking, model registry, and an automated promotion gate that only
> deploys a model when it beats the current Production version's ROC-AUC.

> Caught and fixed a data leakage bug during model development (ROC-AUC
> dropped from an unrealistic 1.0 to a defensible 0.91 after removing a
> label-derived feature), and added a regression test to prevent recurrence.

> Simulated and documented a production data-quality incident (score drop
> from 95.9% to 66.8%), demonstrating automated detection, pipeline
> blocking, and recovery -- see `docs/incident_postmortem.md`.
